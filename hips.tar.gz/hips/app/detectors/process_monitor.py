import subprocess
from datetime import datetime
from app.utils.logger import log_alarma
import re

# ─── Lista de procesos típicos usados en ataques ────────────────────────────────
SUSPICIOUS_PROCESSES = [
    "nc", "ncat", "netcat", "tcpdump", "wireshark", "metasploit", "hydra",
    "john", "sqlmap", "msfconsole", "powershell", "bash"
]

def check_suspicious_processes(whitelist):
    """
    Escanea procesos activos y detecta si hay procesos sospechosos
    que no estén dentro del whitelist definido en config.json.
    Devuelve lista de alertas y PIDs.
    """
    alerts = []
    suspicious_pids = []

    try:
        ps_output = subprocess.check_output(["ps", "aux"], text=True)
        lines = ps_output.strip().split('\n')[1:]  # Saltar encabezado

        for line in lines:
            # Saltear si es parte del whitelist
            if any(proc in line for proc in whitelist):
                continue

            for target in SUSPICIOUS_PROCESSES:
                # Detectar nombre exacto de proceso
                if re.search(rf'\b{re.escape(target)}\b', line):
                    parts = line.split()
                    pid = int(parts[1]) if len(parts) > 1 and parts[1].isdigit() else -1
                    timestamp = datetime.now().strftime('%d/%m/%Y %H:%M:%S')
                    alert = f"{timestamp} :: Proceso sospechoso detectado: {target} (PID {pid}) :: localhost"
                    alerts.append(alert)
                    suspicious_pids.append(pid)
                    log_alarma("Proceso sospechoso", alert)
                    break  # evitar múltiples alertas para misma línea

    except Exception as e:
        alerts.append(f"Error al escanear procesos: {str(e)}")

    return alerts, suspicious_pids