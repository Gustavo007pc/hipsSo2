import os
import subprocess
import psutil
from datetime import datetime
from app.utils.logger import log_alarma, log_prevencion
from app.utils.mailer import enviar_alerta_mail

# Palabras clave sospechosas
SUSPICIOUS_KEYWORDS = ["miner", "shell", "bot", "mal", "rat", "backdoor"]

TMP_DIR = "/tmp"

def es_binario_ejecutable(path):
    """
    Usa 'file' para identificar si es un ELF o script.
    """
    try:
        result = subprocess.run(["file", path], capture_output=True, text=True)
        info = result.stdout.lower()
        return "elf" in info or "script" in info or "executable" in info
    except Exception:
        return False

def eliminar_tmp_procesos_y_archivos(config=None):
    alerts = []
    timestamp = datetime.now().strftime('%d/%m/%Y %H:%M:%S')

    # 1. Procesos ejecutándose desde /tmp
    for proc in psutil.process_iter(['pid', 'name', 'exe', 'cmdline']):
        try:
            pid = proc.info['pid']
            cmd = " ".join(proc.info['cmdline']) if proc.info['cmdline'] else ""
            exe = proc.info['exe'] or ""

            if "/tmp/" in cmd or "/tmp/" in exe:
                if any(k in cmd.lower() for k in SUSPICIOUS_KEYWORDS):
                    alerta = f"{timestamp} :: Proceso sospechoso desde /tmp detectado: {cmd} (PID {pid})"
                    alerts.append(alerta)
                    log_alarma("Proceso /tmp", alerta)
                    log_prevencion("Proceso eliminado", f"PID {pid} eliminado desde /tmp")
                    enviar_alerta_mail(config, "⚠️ Proceso en /tmp", alerta)
                    proc.kill()
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            continue

    # 2. Archivos peligrosos en /tmp
    for root, dirs, files in os.walk(TMP_DIR):
        for fname in files:
            path = os.path.join(root, fname)
            try:
                if any(k in fname.lower() for k in SUSPICIOUS_KEYWORDS) or es_binario_ejecutable(path):
                    alerta = f"{timestamp} :: Archivo sospechoso en /tmp: {path}"
                    alerts.append(alerta)
                    log_alarma("Archivo /tmp", alerta)
                    log_prevencion("Archivo eliminado", f"{path} eliminado")
                    enviar_alerta_mail(config, "⚠️ Binario sospechoso en /tmp", alerta)
                    os.chmod(path, 0o644)
                    os.remove(path)
            except Exception as e:
                log_alarma("Error /tmp", f"{path} → {e}")
    return alerts