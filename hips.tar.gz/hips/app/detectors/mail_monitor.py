import re
import subprocess
from collections import defaultdict
from datetime import datetime
from app.utils.logger import log_alarma, log_prevencion
from app.utils.mailer import enviar_alerta_mail

def get_postfix_logs():
    """
    Extrae los logs del servicio postfix usando journalctl.
    """
    try:
        result = subprocess.run(
            ["journalctl", "-u", "postfix", "--no-pager", "--since", "today"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=10
        )
        if result.returncode != 0:
            log_alarma("Postfix", f"Error al obtener logs: {result.stderr.strip()}")
            return []
        return result.stdout.splitlines()
    except Exception as e:
        log_alarma("Postfix", f"Excepción al ejecutar journalctl: {e}")
        return []

def parse_journal_logs():
    """
    Parsea los logs y retorna un dict: { remitente: [timestamp1, timestamp2, ...] }
    """
    pattern = re.compile(r"from=<([^>]+)>")
    user_times = defaultdict(list)
    logs = get_postfix_logs()

    for line in logs:
        match = pattern.search(line)
        if match:
            sender = match.group(1)
            try:
                date_str = " ".join(line.split()[:3])  # Ej: Jul 24 04:02:01
                dt = datetime.strptime(date_str, "%b %d %H:%M:%S")
                dt = dt.replace(year=datetime.now().year)
                user_times[sender].append(dt)
            except Exception:
                continue
    return user_times

def detect_mass_mailing(config):
    """
    Detecta si algún usuario está enviando correos masivos en corto tiempo.
    """
    alerts = []
    settings = config.get("settings", {})
    MAX_MAILS = settings.get("MAX_MAILS", 10)
    TIME_WINDOW = settings.get("MAIL_TIME_WINDOW", 60)
    user_times = parse_journal_logs()
    timestamp = datetime.now().strftime("%d/%m/%Y %H:%M:%S")

    for sender, times in user_times.items():
        times.sort()
        for i in range(len(times)):
            count = 1
            for j in range(i + 1, len(times)):
                if (times[j] - times[i]).total_seconds() <= TIME_WINDOW:
                    count += 1
                else:
                    break
            if count > MAX_MAILS:
                alerta = f"{timestamp} :: Envío masivo detectado para {sender} :: {count} mails en ≤ {TIME_WINDOW}s"
                alerts.append(alerta)
                log_alarma("Envío masivo", alerta)
                log_prevencion("Correo masivo", f"Remitente sospechoso: {sender}")
                enviar_alerta_mail(config, "⚠️ Envío masivo detectado", alerta)
                break
    return alerts

if __name__ == "__main__":
    import json
    try:
        with open("config.json") as f:
            config = json.load(f)
    except:
        config = {"settings": {"MAX_MAILS": 10, "MAIL_TIME_WINDOW": 60}}
    for a in detect_mass_mailing(config):
        print(a)