import subprocess
import re
from datetime import datetime
from app.utils.logger import log_alarma, log_prevencion
from app.utils.mailer import enviar_alerta_mail

DEFAULT_KEYWORDS = [
    "Failed password", "authentication failure", "sudo",
    "su: authentication failure", "session opened for user", "Accepted password"
]

def get_journal_logs(keywords, max_lines=1000):
    cmd = ["journalctl", "-o", "cat", "-n", str(max_lines)]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, check=True)
        lines = result.stdout.splitlines()
        filtered = [line for line in lines if any(k in line for k in keywords)]
        return filtered
    except subprocess.CalledProcessError as e:
        print(f"[ERROR] journalctl falló: {e}")
        return []

def extraer_timestamp(linea):
    # journalctl ya incluye fecha en líneas con formato estándar
    match = re.search(r'^\w+\s+\d+\s+\d+:\d+:\d+', linea)
    return match.group() if match else datetime.now().strftime('%d/%m/%Y %H:%M:%S')

def clasificar_evento(linea):
    line_lower = linea.lower()
    if "failed password" in line_lower or "authentication failure" in line_lower:
        return "❌ Login fallido"
    elif "sudo" in line_lower and "command" in line_lower:
        return "⚠️ Uso de sudo"
    elif "su:" in line_lower and "authentication failure" in line_lower:
        return "🚫 Su fallido"
    elif "session opened for user root" in line_lower:
        return "⚠️ Escalada a root"
    elif "accepted password" in line_lower:
        return "✅ Login exitoso"
    else:
        return "📌 Evento de autenticación"

def analyze_auth_logs(config=None):
    settings = config.get("settings", {}) if config else {}
    max_lines = settings.get("LOG_LINES", 1000)
    keywords = settings.get("AUTH_LOG_KEYWORDS", DEFAULT_KEYWORDS)

    eventos = []
    logs = get_journal_logs(keywords, max_lines)

    for line in logs:
        ts = extraer_timestamp(line)
        tipo = clasificar_evento(line)
        mensaje = f"{ts} :: {tipo} :: {line}"
        eventos.append(mensaje)

        if tipo in ["❌ Login fallido", "🚫 Su fallido", "⚠️ Escalada a root"]:
            log_alarma("Logs de autenticación", mensaje)
            enviar_alerta_mail(config, f"🚨 {tipo}", mensaje)
        elif tipo == "⚠️ Uso de sudo":
            log_prevencion("Uso de sudo", mensaje)
        else:
            log_prevencion("Log informativo", mensaje)

    return eventos